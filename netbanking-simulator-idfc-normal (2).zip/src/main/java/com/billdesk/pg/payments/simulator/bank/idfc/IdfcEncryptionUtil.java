package com.billdesk.pg.payments.simulator.bank.idfc;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

/**
 * Direct port of IDFC's {@code EncryptionUtils} (IDFC Bank Payments ECOM Integration PDF, §5,
 * "Logic for encryption and decryption"). AES/ECB/PKCS5Padding, key = first 16 bytes of
 * SHA-256(merchant secret), body Base64-encoded. Kept line-for-line so it stays verifiably
 * identical to what the real bank encrypts/decrypts against.
 */
final class IdfcEncryptionUtil {

  private IdfcEncryptionUtil() {

  }

  private static SecretKeySpec deriveKey(String secret) {

    try {
      MessageDigest sha = MessageDigest.getInstance("SHA-256");
      byte[] key = sha.digest(secret.getBytes(StandardCharsets.UTF_8));
      key = Arrays.copyOf(key, 16);
      return new SecretKeySpec(key, "AES");
    } catch (Exception e) {
      throw new IllegalStateException("Unable to derive IDFC AES key", e);
    }
  }

  static String encrypt(String strToEncrypt, String secret) {

    try {
      SecretKeySpec secretKey = deriveKey(secret);
      Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
      cipher.init(Cipher.ENCRYPT_MODE, secretKey);
      return Base64.getEncoder()
                  .encodeToString(cipher.doFinal(strToEncrypt.getBytes(StandardCharsets.UTF_8)));
    } catch (Exception e) {
      throw new IllegalStateException("Error while encrypting IDFC payload: " + e, e);
    }
  }

  static String decrypt(String strToDecrypt, String secret) {

    try {
      SecretKeySpec secretKey = deriveKey(secret);
      Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
      cipher.init(Cipher.DECRYPT_MODE, secretKey);
      return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)),
                        StandardCharsets.UTF_8);
    } catch (Exception e) {
      throw new IllegalStateException("Error while decrypting IDFC payload: " + e, e);
    }
  }
}
