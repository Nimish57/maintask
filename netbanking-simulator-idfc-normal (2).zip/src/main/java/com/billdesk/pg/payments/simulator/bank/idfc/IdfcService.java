package com.billdesk.pg.payments.simulator.bank.idfc;

import com.billdesk.pg.payments.simulator.core.NetbankingBankSimulator;
import com.billdesk.pg.payments.simulator.dto.CallbackDelivery;
import com.billdesk.pg.payments.simulator.dto.ParsedInit;
import com.billdesk.pg.payments.simulator.dto.SimulatedCase;
import com.billdesk.pg.payments.simulator.dto.ValidationResult;
import com.billdesk.pg.payments.simulator.dto.VerificationWireResponse;
import com.billdesk.pg.payments.simulator.model.SimulatorRecord;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

/**
 * The IDFC bank-specific service, wired into the existing generic {@code SimulatorController} /
 * {@code SimulatorService} exactly the way {@code HreService} is — no bank-specific controller,
 * no separate OAuth/Status/Refund endpoints. Two legs only, same as every other bank in the
 * simulator:
 * <ul>
 *   <li><b>Init + callback</b> (PDF §6, "Transaction API") — PG's {@code TXN_INIT_URL} POST to
 *       {@code /simulator/netbanking/IDFC} carries the encrypted envelope's four fields
 *       ({@code isEncReq/mid/encParams/serviceName}) as flat form fields; {@link #preprocessInit}
 *       decrypts {@code encParams} into plain MID/PID/AMT/... fields so the rest of this class
 *       (and {@code SimulatorService}) works off plain fields exactly like HRE's already-plain
 *       form fields.
 *   <li><b>Verification</b> (PDF §7) — deliberately reuses the existing double-verification leg
 *       (PG's {@code QRY_INIT_URL} call to {@code /simulator/netbanking/checkTxnStatus/IDFC}),
 *       the same route HRE's verification uses, instead of standing up IDFC's separate
 *       OAuth2-protected {@code /enterprise-ecom/v1/encrypted/transaction/verification} REST API.
 *       The request/response field shapes (and the AES/HMAC-SHA512 checksum) still follow PDF
 *       §7's Verification API — only the transport (which URL carries it, and skipping the
 *       OAuth2 bearer-token check) is simplified to match how the simulator already works.
 * </ul>
 * Status and Refund (PDF §8-9) are intentionally not implemented — out of scope for this
 * simulator. Only PDF §6's "Normal Transaction" shape is supported (ACCNO always optional/blank,
 * no MCC=6211 Mutual Fund handling) — see §6's Normal Transaction example:
 * {@code MID|PID|AMT|RETURL|TXNTYPE|ACCNO|NAR|CHNL|MCC|CUR} with ACCNO left empty.
 */
@Component
public class IdfcService implements NetbankingBankSimulator {

  private static final Logger logger = LogManager.getLogger(IdfcService.class);
  private static final ObjectMapper MAPPER = new ObjectMapper();

  private static final List<String> REQUIRED_INIT_FIELDS =
                                                          List.of("MID", "PID", "AMT", "RETURL",
                                                                 "TXNTYPE", "NAR", "CHNL", "MCC",
                                                                 "CUR", "CHECKSUM");

  private static final List<String> REQUIRED_VERIFY_FIELDS =
                                                            List.of("MID", "PID", "AMT", "TXNTYPE",
                                                                   "BID", "MCC", "CHECKSUM");

  /** Curated from PDF §10 for the simulator page's failure-reason dropdown. */
  public static final List<String> KNOWN_FAILURE_REASONS =
                                                          List.of("Account/Transaction Failure",
                                                                 "You have exceeded your third party funds transfer limit for the day.",
                                                                 "Session Time out. Please re-initiate the transaction.",
                                                                 "Your account has not been activated for netbanking. Please contact the bank.",
                                                                 "Funds transfer terminated by user.");

  @Value("${simulator.idfc.checksum-key:}")
  private String checksumKey;

  @Value("${simulator.idfc.encryption-key:}")
  private String encryptionKey;

  @Override
  public String bankId() {

    return "IDFC";
  }

  /**
   * Decrypts {@code encParams} (AES/ECB/PKCS5, PDF §6/§7's key-value array
   * {@code [{"k":"MID","v":"..."}...]}) into a flat field map. Also used, via
   * {@link #decryptFields}, on the verification leg — the interface has no equivalent
   * "preprocessVerification" hook.
   */
  @Override
  public Map<String, String> preprocessInit(Map<String, String> rawFields) {

    Map<String, String> decrypted = decryptFields(rawFields);
    return decrypted != null ? decrypted : rawFields;
  }

  @SuppressWarnings("unchecked")
  private Map<String, String> decryptFields(Map<String, String> envelope) {

    String encParams = envelope.get("encParams");
    if (encParams == null || encParams.isBlank()) {
      // Already-flat fields (e.g. a plaintext/non-encrypted test call) — degrade gracefully.
      return null;
    }
    try {
      String decryptedJson = IdfcEncryptionUtil.decrypt(encParams, encryptionKey);
      List<Map<String, String>> pairs = MAPPER.readValue(decryptedJson, List.class);
      Map<String, String> flat = new LinkedHashMap<>();
      for (Map<String, String> pair : pairs) {
        flat.put(pair.get("k"), pair.get("v"));
      }
      return flat;
    } catch (Exception e) {
      logger.warn("Could not decrypt/parse IDFC encParams as [{{k,v}}...] array", e);
      return Map.of();
    }
  }

  @Override
  public ValidationResult validateInit(Map<String, String> raw) {

    for (String field : REQUIRED_INIT_FIELDS) {
      String value = raw.get(field);
      if (value == null || value.isBlank()) {
        return ValidationResult.fail(field, "required field missing or blank");
      }
    }
    try {
      double amount = Double.parseDouble(raw.get("AMT"));
      if (amount < 0) {
        return ValidationResult.fail("AMT", "must be non-negative");
      }
    } catch (NumberFormatException e) {
      return ValidationResult.fail("AMT", "not a valid decimal amount");
    }
    if (checksumKey != null && !checksumKey.isBlank()) {
      String expected = IdfcChecksumUtil.calculateChecksum(IdfcChecksumUtil.buildPaymentChecksumString(raw),
                                                            checksumKey);
      if ( !expected.equalsIgnoreCase(raw.get("CHECKSUM"))) {
        logger.warn("IDFC payment CHECKSUM mismatch for PID={} expected={} received={}",
                   raw.get("PID"),
                   expected,
                   raw.get("CHECKSUM"));
        return ValidationResult.fail("CHECKSUM", "recomputed checksum does not match");
      }
    } else {
      logger.info("IDFC payment CHECKSUM presence-only check (no simulator.idfc.checksum-key configured) for PID={}",
                 raw.get("PID"));
    }
    return ValidationResult.ok();
  }

  @Override
  public ParsedInit parseInit(Map<String, String> raw) {

    return new ParsedInit(raw.get("PID"), raw.get("MID"), raw.get("AMT"), raw.get("CUR"),
                          raw.get("RETURL"));
  }

  /**
   * Builds the encrypted callback envelope PG receives after the tester's outcome (PDF §6's
   * "encrypted response structure": {@code {isEncReq, encParams, responseCode, mid}}, where
   * {@code encParams} is the AES-encrypted {@code merchant_response} JSON object). Delivered as a
   * JSON POST body (see {@link CallbackDelivery}'s JSON-body constructor), matching PDF §6 rather
   * than HRE's query-string redirect. The exact checksum field order for the *payment* response
   * isn't documented the way Verification's is (§7.4 spells that one out) — this reuses
   * Verification's response field order as a best-effort match; confirm against real IDFC UAT
   * responses before relying on it downstream.
   */
  @Override
  public CallbackDelivery buildCallbackResponse(SimulatorRecord record, SimulatedCase chosenCase) {

    String responseCode = chosenCase.isSuccess() ? "SUC000" : "ACT001";
    Map<String, String> merchantResponse = new LinkedHashMap<>();
    merchantResponse.put("BID", record.getBankRef());
    merchantResponse.put("ACCNO", "");
    merchantResponse.put("ResponseCode", responseCode);
    merchantResponse.put("TxnType", "Payment");
    merchantResponse.put("AMT", record.getTxnAmount());
    merchantResponse.put("ResponseMsg", chosenCase.isSuccess()
      ? "Success"
      : effectiveFailureReason(chosenCase));
    merchantResponse.put("MID", record.getMercId());
    merchantResponse.put("PAID", chosenCase.isSuccess() ? "Y" : "N");
    merchantResponse.put("PID", record.getTxnId());
    merchantResponse.put("RetURL", record.getReturnUrl());
    merchantResponse.put("NAR", "");
    merchantResponse.put("TotalAmount", record.getTxnAmount());
    merchantResponse.put("RequestType", "Payment");
    merchantResponse.put("Checksum", checksumKey != null && !checksumKey.isBlank()
      ? IdfcChecksumUtil.calculateChecksum(IdfcChecksumUtil.buildVerificationResponseChecksumString(merchantResponse),
                                          checksumKey)
      : "");

    String encParams;
    try {
      String jsonBody = MAPPER.writeValueAsString(Map.of("merchant_response", merchantResponse));
      encParams = IdfcEncryptionUtil.encrypt(jsonBody, encryptionKey);
    } catch (Exception e) {
      logger.warn("Could not build/encrypt IDFC callback response for PID={}", record.getTxnId(), e);
      encParams = "";
    }

    String envelope;
    try {
      envelope = MAPPER.writeValueAsString(Map.of("isEncReq", "Y",
                                                  "encParams", encParams,
                                                  "responseCode", responseCode,
                                                  "mid", record.getMercId()));
    } catch (Exception e) {
      envelope = "{}";
    }
    return new CallbackDelivery(record.getReturnUrl(), envelope, HttpMethod.POST);
  }

  /**
   * Verification, routed through the existing double-verification leg (see class javadoc) — the
   * verify call carries the same four-field envelope as init; decrypts, checks required fields +
   * checksum, then cross-checks the decrypted MID/PID/AMT against what was captured at init
   * (mirrors {@code HreService#validateVerification}'s echoed-fields check).
   */
  @Override
  public ValidationResult validateVerification(Map<String, String> rawParams, SimulatorRecord record) {

    Map<String, String> fields = decryptFields(rawParams);
    if (fields == null || fields.isEmpty()) {
      return ValidationResult.fail("encParams", "missing or undecryptable on verification call");
    }
    for (String field : REQUIRED_VERIFY_FIELDS) {
      String value = fields.get(field);
      if (value == null || value.isBlank()) {
        return ValidationResult.fail(field, "required field missing or blank on verification call");
      }
    }
    if ( !"Verification".equalsIgnoreCase(fields.get("TXNTYPE"))) {
      return ValidationResult.fail("TXNTYPE", "expected literal 'Verification'");
    }
    if ( !fields.get("MID").equals(record.getMercId())) {
      return ValidationResult.fail("MID", "does not match value captured at init");
    }
    if ( !fields.get("PID").equals(record.getTxnId())) {
      return ValidationResult.fail("PID", "does not match transaction id captured at init");
    }
    if ( !fields.get("AMT").equals(record.getTxnAmount())) {
      return ValidationResult.fail("AMT", "does not match amount captured at init");
    }
    if (checksumKey != null && !checksumKey.isBlank()) {
      String expected = IdfcChecksumUtil.calculateChecksum(IdfcChecksumUtil.buildVerificationChecksumString(fields),
                                                            checksumKey);
      if ( !expected.equalsIgnoreCase(fields.get("CHECKSUM"))) {
        return ValidationResult.fail("CHECKSUM", "recomputed checksum does not match");
      }
    }
    return ValidationResult.ok();
  }

  /**
   * Builds the encrypted Verification response (PDF §7.8: {@code {respCode, response, errorMsg}},
   * where {@code response} is the AES-encrypted key-value array of MID/PID/AMT/ACCNO/TXNTYPE/BID/
   * TXNSTATUS/RESPONSECODE/RESPONSEMSG with its own checksum, per §7.6/§7.4).
   */
  @Override
  public VerificationWireResponse buildVerificationResponse(SimulatorRecord record,
                                                             SimulatedCase chosenCase) {

    String responseCode = chosenCase.isSuccess() ? "SUC000" : "ACT001";
    Map<String, String> fields = new LinkedHashMap<>();
    fields.put("MID", record.getMercId());
    fields.put("PID", record.getTxnId());
    fields.put("AMT", record.getTxnAmount());
    fields.put("ACCNO", "");
    fields.put("TXNTYPE", "Verification");
    fields.put("BID", record.getBankRef());
    fields.put("MCC", "");
    fields.put("TXNSTATUS", chosenCase.isSuccess() ? "SUCCESS" : "FAILURE");
    fields.put("RESPONSECODE", responseCode);
    fields.put("RESPONSEMSG", chosenCase.isSuccess() ? "Success" : effectiveFailureReason(chosenCase));
    if (checksumKey != null && !checksumKey.isBlank()) {
      fields.put("CHECKSUM", IdfcChecksumUtil.calculateChecksum(IdfcChecksumUtil.buildVerificationResponseChecksumString(fields),
                                                                checksumKey));
    }
    return encryptedVerificationResponse(responseCode, fields);
  }

  @Override
  public VerificationWireResponse buildMismatchVerificationResponse(SimulatorRecord record,
                                                                     ValidationResult failure) {

    logger.warn("IDFC verification-call mismatch for txn={} field={} reason={}",
               record.getTxnId(),
               failure.getField(),
               failure.getMessage());
    String body = "{\"error_code\":\"ERR_BAD_REQUEST\",\"error_message\":\""
                 + failure.getField() + ": " + failure.getMessage() + "\"}";
    return new VerificationWireResponse("application/json", body,
                                       failure.getField() + ": " + failure.getMessage());
  }

  @Override
  public String extractVerificationTxnId(Map<String, String> rawParams) {

    Map<String, String> fields = decryptFields(rawParams);
    return fields == null ? null : fields.get("PID");
  }

  @Override
  public List<String> knownFailureReasons() {

    return KNOWN_FAILURE_REASONS;
  }

  private VerificationWireResponse encryptedVerificationResponse(String responseCode,
                                                                  Map<String, String> fields) {

    try {
      List<Map<String, String>> pairs = new ArrayList<>();
      for (Map.Entry<String, String> entry : fields.entrySet()) {
        pairs.add(Map.of("k", entry.getKey(), "v", entry.getValue()));
      }
      String encParams = IdfcEncryptionUtil.encrypt(MAPPER.writeValueAsString(pairs), encryptionKey);
      String body = MAPPER.writeValueAsString(Map.of("respCode", responseCode,
                                                     "response", encParams,
                                                     "errorMsg", "SUC000".equals(responseCode)
                                                       ? "Success"
                                                       : fields.getOrDefault("RESPONSEMSG", "Failure")));
      return new VerificationWireResponse("application/json", body);
    } catch (Exception e) {
      logger.warn("Could not build/encrypt IDFC verification response", e);
      return new VerificationWireResponse("application/json",
                                         "{\"error_code\":\"ERR_INTERNAL_SERVER_ERROR\",\"error_message\":\""
                                         + e.getMessage() + "\"}");
    }
  }

  private String effectiveFailureReason(SimulatedCase chosenCase) {

    String reason = chosenCase.getFailureReason();
    return (reason == null || reason.isBlank()) ? KNOWN_FAILURE_REASONS.get(0) : reason;
  }
}
