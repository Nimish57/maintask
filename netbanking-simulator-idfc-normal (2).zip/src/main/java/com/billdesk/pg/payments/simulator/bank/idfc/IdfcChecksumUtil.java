package com.billdesk.pg.payments.simulator.bank.idfc;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Map;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/**
 * Direct port of IDFC's {@code GenerateChecksum.getSecureSHAHash} (IDFC Bank Payments ECOM
 * Integration PDF, §5) plus the Payment/Verification pipe-separated field orders from §6-7 (this
 * simulator only supports the Normal Transaction flow — no Status/Refund APIs, no Mutual Fund/
 * MCC=6211 handling). HmacSHA512, and per §5 "The key needs to be base64 encoded first" — the raw
 * secret is base64-encoded before being used as the HMAC key, unlike HRE's checksum (which uses
 * the secret verbatim).
 */
final class IdfcChecksumUtil {

  private IdfcChecksumUtil() {

  }

  private static String nz(String v) {

    return v == null ? "" : v;
  }

  /** {@code GenerateChecksum.getSecureSHAHash} — HmacSHA512 over dataString, uppercase hex out. */
  static String calculateChecksum(String dataString, String secretKey) {

    try {
      String base64Key = Base64.getEncoder()
                                .encodeToString(secretKey.getBytes(StandardCharsets.UTF_8));
      Mac mac = Mac.getInstance("HmacSHA512");
      mac.init(new SecretKeySpec(base64Key.getBytes(StandardCharsets.UTF_8), "HmacSHA512"));
      return toHex(mac.doFinal(dataString.getBytes(StandardCharsets.UTF_8)));
    } catch (Exception e) {
      throw new IllegalStateException("Unable to compute IDFC checksum", e);
    }
  }

  private static String toHex(byte[] input) {

    char[] hexTable = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
    StringBuilder sb = new StringBuilder(input.length * 2);
    for (byte b : input) {
      sb.append(hexTable[(b >> 4) & 0xF]);
      sb.append(hexTable[b & 0xF]);
    }
    return sb.toString();
  }

  // --- Payment (Transaction initiate) — PDF §6 -------------------------------------------------

  /** MID|PID|AMT|RETURL|TXNTYPE|ACCNO|NAR|CHNL|MCC|CUR */
  static String buildPaymentChecksumString(Map<String, String> f) {

    return nz(f.get("MID")) + "|" + nz(f.get("PID")) + "|" + nz(f.get("AMT")) + "|"
          + nz(f.get("RETURL")) + "|" + nz(f.get("TXNTYPE")) + "|" + nz(f.get("ACCNO")) + "|"
          + nz(f.get("NAR")) + "|" + nz(f.get("CHNL")) + "|" + nz(f.get("MCC")) + "|"
          + nz(f.get("CUR"));
  }

  // --- Verification — PDF §7 --------------------------------------------------------------------

  /** Request: MID|PID|AMT|ACCNO|TXNTYPE|BID|MCC */
  static String buildVerificationChecksumString(Map<String, String> f) {

    return nz(f.get("MID")) + "|" + nz(f.get("PID")) + "|" + nz(f.get("AMT")) + "|"
          + nz(f.get("ACCNO")) + "|" + nz(f.get("TXNTYPE")) + "|" + nz(f.get("BID")) + "|"
          + nz(f.get("MCC"));
  }

  /** Response: MID|PID|AMT|ACCNO|TXNTYPE|BID|TXNSTATUS|RESPONSECODE|RESPONSEMSG */
  static String buildVerificationResponseChecksumString(Map<String, String> f) {

    return nz(f.get("MID")) + "|" + nz(f.get("PID")) + "|" + nz(f.get("AMT")) + "|"
          + nz(f.get("ACCNO")) + "|" + nz(f.get("TXNTYPE")) + "|" + nz(f.get("BID")) + "|"
          + nz(f.get("TXNSTATUS")) + "|" + nz(f.get("RESPONSECODE")) + "|"
          + nz(f.get("RESPONSEMSG"));
  }
}
