package com.billdesk.pg.payments.simulator.dto;

import java.util.Map;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;

/**
 * What to send the browser back to on the callback/return leg, and how to fire the matching S2S
 * call to the same URL (design doc §2/§3.1's "how each bank redirects back" — for HRE, a 302 to
 * the captured DynamicUrl with these as query params, per HRE.md §2's sequence diagram; open
 * question §10.3 flags this transport as worth confirming against the real api-side handler
 * before treating it as final). The HTTP method for the S2S leg is bank-declared here rather than
 * hardcoded in the generic delivery code, so a bank whose S2S call isn't a plain GET can say so
 * without any change outside its own plugin.
 *
 * <p>Two shapes: query-params (HRE's redirect-style GET/POST) or a raw JSON body (IDFC's RETURL
 * callback, PDF §6 — {@code {isEncReq, encParams, responseCode, mid}} POSTed as
 * {@code application/json}). Exactly one of {@link #getQueryParams()} / {@link #getJsonBody()} is
 * non-null; {@code service.SimulatorService#fireS2SCallback} branches on which.
 */
public class CallbackDelivery {

  private final String targetUrl;
  private final Map<String, String> queryParams;
  private final String jsonBody;
  private final HttpMethod s2sMethod;

  public CallbackDelivery(String targetUrl, Map<String, String> queryParams) {

    this(targetUrl, queryParams, HttpMethod.GET);
  }

  public CallbackDelivery(String targetUrl, Map<String, String> queryParams, HttpMethod s2sMethod) {

    this.targetUrl = targetUrl;
    this.queryParams = queryParams;
    this.jsonBody = null;
    this.s2sMethod = s2sMethod;
  }

  /** JSON-body callback variant (e.g. IDFC) — no query params, body POSTed as-is. */
  public CallbackDelivery(String targetUrl, String jsonBody, HttpMethod s2sMethod) {

    this.targetUrl = targetUrl;
    this.queryParams = null;
    this.jsonBody = jsonBody;
    this.s2sMethod = s2sMethod;
  }

  public String getTargetUrl() {

    return targetUrl;
  }

  public Map<String, String> getQueryParams() {

    return queryParams;
  }

  /** Non-null only for the JSON-body variant; {@link #getQueryParams()} is null in that case. */
  public String getJsonBody() {

    return jsonBody;
  }

  public HttpMethod getS2sMethod() {

    return s2sMethod;
  }

  public MediaType getBodyContentType() {

    return MediaType.APPLICATION_JSON;
  }
}
