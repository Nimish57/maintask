package com.billdesk.pg.payments.simulator.bank.idfc;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Map;
import org.junit.jupiter.api.Test;

/**
 * Simple checks for {@link IdfcChecksumUtil} against PDF §6's Normal Transaction pipe-string
 * format and §5's "same input + same key -> same checksum" HMAC-SHA512 behavior.
 */
class IdfcChecksumUtilTest {

  @Test
  void buildPaymentChecksumString_matchesNormalTransactionPipeOrder() {

    // PDF §6 Normal Transaction example:
    // MER001101|TM141256|1.00|https://cppro1.xyz.com/api/v1/res|Payment||MobilePurchases|01|3020|INR
    Map<String, String> fields = Map.of("MID", "MER001101",
                                       "PID", "TM141256",
                                       "AMT", "1.00",
                                       "RETURL", "https://cppro1.xyz.com/api/v1/res",
                                       "TXNTYPE", "Payment",
                                       "ACCNO", "",
                                       "NAR", "MobilePurchases",
                                       "CHNL", "01",
                                       "MCC", "3020",
                                       "CUR", "INR");

    String pipeString = IdfcChecksumUtil.buildPaymentChecksumString(fields);

    assertThat(pipeString).isEqualTo("MER001101|TM141256|1.00|https://cppro1.xyz.com/api/v1/res"
                                     + "|Payment||MobilePurchases|01|3020|INR");
  }

  @Test
  void calculateChecksum_isDeterministicAndKeySensitive() {

    String data = "MER001101|TM141256|1.00|https://cppro1.xyz.com/api/v1/res|Payment||MobilePurchases|01|3020|INR";

    String checksum1 = IdfcChecksumUtil.calculateChecksum(data, "test123");
    String checksum2 = IdfcChecksumUtil.calculateChecksum(data, "test123");
    String checksumDifferentKey = IdfcChecksumUtil.calculateChecksum(data, "different-key");

    assertThat(checksum1).isEqualTo(checksum2);
    assertThat(checksum1).isNotEqualTo(checksumDifferentKey);
  }

  @Test
  void buildPaymentChecksumString_treatsAbsentFieldsAsEmpty() {

    // ACCNO isn't just "" here — it's entirely missing from the map, exercising the nz() null
    // path (as opposed to the other test's explicit empty string).
    Map<String, String> fields = Map.of("MID", "MER001101",
                                       "PID", "TM141256",
                                       "AMT", "1.00",
                                       "RETURL", "https://cppro1.xyz.com/api/v1/res",
                                       "TXNTYPE", "Payment",
                                       "NAR", "MobilePurchases",
                                       "CHNL", "01",
                                       "MCC", "3020",
                                       "CUR", "INR");

    String pipeString = IdfcChecksumUtil.buildPaymentChecksumString(fields);

    assertThat(pipeString).isEqualTo("MER001101|TM141256|1.00|https://cppro1.xyz.com/api/v1/res"
                                     + "|Payment||MobilePurchases|01|3020|INR");
  }

  @Test
  void buildVerificationChecksumString_matchesFieldOrder() {

    // PDF §7 Verification request order: MID|PID|AMT|ACCNO|TXNTYPE|BID|MCC
    Map<String, String> fields = Map.of("MID", "MER001101",
                                       "PID", "TM141256",
                                       "AMT", "1.00",
                                       "ACCNO", "",
                                       "TXNTYPE", "Payment",
                                       "BID", "BID12345",
                                       "MCC", "3020");

    String pipeString = IdfcChecksumUtil.buildVerificationChecksumString(fields);

    assertThat(pipeString).isEqualTo("MER001101|TM141256|1.00||Payment|BID12345|3020");
  }

  @Test
  void buildVerificationResponseChecksumString_matchesFieldOrder() {

    // PDF §7 Verification response order:
    // MID|PID|AMT|ACCNO|TXNTYPE|BID|TXNSTATUS|RESPONSECODE|RESPONSEMSG
    Map<String, String> fields = Map.of("MID", "MER001101",
                                       "PID", "TM141256",
                                       "AMT", "1.00",
                                       "ACCNO", "",
                                       "TXNTYPE", "Payment",
                                       "BID", "BID12345",
                                       "TXNSTATUS", "0300",
                                       "RESPONSECODE", "R1000",
                                       "RESPONSEMSG", "Approved");

    String pipeString = IdfcChecksumUtil.buildVerificationResponseChecksumString(fields);

    assertThat(pipeString).isEqualTo(
        "MER001101|TM141256|1.00||Payment|BID12345|0300|R1000|Approved");
  }
}
