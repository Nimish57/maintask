package com.billdesk.pg.payments.simulator.bank.idfc;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

/**
 * Simple round-trip check for {@link IdfcEncryptionUtil} — encrypting then decrypting the same
 * plaintext with the same key should return the original string (PDF §5's AES/ECB/PKCS5Padding
 * logic).
 */
class IdfcEncryptionUtilTest {

  @Test
  void encryptThenDecrypt_returnsOriginalPlaintext() {

    String plaintext = "[{\"k\":\"MID\",\"v\":\"MER000112\"},{\"k\":\"PID\",\"v\":\"TM141256\"}]";
    String secret = "test123";

    String encrypted = IdfcEncryptionUtil.encrypt(plaintext, secret);
    String decrypted = IdfcEncryptionUtil.decrypt(encrypted, secret);

    assertThat(decrypted).isEqualTo(plaintext);
  }

  @Test
  void decryptWithWrongKey_doesNotReturnOriginalPlaintext() {

    String plaintext = "hello IDFC";
    String encrypted = IdfcEncryptionUtil.encrypt(plaintext, "correct-key");

    // A wrong key either throws (bad padding) or yields garbage — either way, it must never
    // silently produce the original plaintext.
    String result;
    try {
      result = IdfcEncryptionUtil.decrypt(encrypted, "wrong-key");
    } catch (Exception e) {
      result = null;
    }

    assertThat(result).isNotEqualTo(plaintext);
  }
}
